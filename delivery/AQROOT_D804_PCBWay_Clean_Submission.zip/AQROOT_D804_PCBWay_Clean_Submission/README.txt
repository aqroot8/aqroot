AQROOT D-804 - PCBWay CAM Recheck Package
Inquiry: W1187157AS5D1

Contents:
- Gerbers/: complete replacement Gerber and drill data for fabrication.
- AQROOT_D804_Stackup_Specification.txt: preferred 6-layer construction and fabrication requirements.
- AQROOT_D804_CAM_Notes.txt: response to the CAM questions previously raised for this inquiry.

Revision: D-804
This package supersedes all earlier AQROOT Gerber files submitted for this inquiry.
