AQROOT D-806 - JLCPCB quotation package
Issued 2026-10-06. Request: 2 assembled PCBAs; quote the required bare-board MOQ separately.

This package replaces D-805 for this quotation. The BOM identities and circuit are unchanged.
Changes: J2 moved inward 0.150 mm (edge clearance 0.363 mm); eight U9 corner lands
shortened 0.030 mm (Gerber clearance 6.562 mil); 35 vias enlarged to 0.40/0.20 mm.
Board outline unchanged. Readable reference locator and dimensioned profile PDFs are included.

Read Fabrication_Assembly_Notes.md, Stackup.txt, Board_Thickness.txt and Panel_Edge_Rails.txt.
Use the fitted placement CSV and BOM; do not fit DNPs.
Board thickness and IR lead-forming/mechanical alignment remain open.
Please quote PCB, parts, assembly/manual operations, tooling, inspection, freight,
lead time and any MOQ/attrition separately.

Please return production files, stackup, panel/routing drawing and placement preview
for written approval before production. No automatic release.
Changes or substitutions require written approval.
Quotation only: fabrication, assembly, payment and component procurement are not authorized.

Board SHA256: 0e59fb64fe72b0a54b9feea96c19bcaec2db52a82a871bcec270e064d7fda547
Files are listed with SHA256 checksums in SHA256SUMS.txt.
