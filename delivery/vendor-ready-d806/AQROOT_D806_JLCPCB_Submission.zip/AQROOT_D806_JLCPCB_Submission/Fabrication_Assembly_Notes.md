AQROOT D-806 - Fabrication and assembly notes
Revision date: 2026-10-06. Units: mm unless indicated otherwise.
Quotation and process review only; production has not been authorized.

1. Outline and routing
Use aqroot-Demo-board-profile.pdf and its JSON coordinate list. Overall extents:
77 x 151 mm. Main body: 72 x 148 mm. Preserve the two bottom connector tabs,
their R1.0 inside fillets and R0.5 outside corners, and the east step.
No V-scoring. At the two sharp inside step corners, retain a routing fillet
with radius <=1.0 mm. Do not over-cut or add corner relief toward copper.
Nearest copper distances at (72,104.005) and (72,70.500), in the Y-down board
frame, are 0.941 mm and 0.726 mm respectively. Return the actual routing/profile
preview and tool radius for approval.

J2 microSD shell-land clearance to the routed edge is 0.363 mm.
U9 minimum different-net clearance measured in the supplied Gerbers is 6.562 mil.
Board-wide different-net minimum is 5.906 mil. Please confirm the finished
post-CAM U9 clearance remains >=4.0 mil. These are supplied-Gerber measurements,
not measurements of your processed production files.

2. Drills and small vias
Minimum via drill: 0.20 mm. Through vias only.
All 915 vias meet outer diameter >= drill diameter +0.20 mm.
The following smaller via geometries require process confirmation:

| count | via dia | drill | annular ring | net |
| --- | --- | --- | --- | --- |
| 6 | 0.40 mm | 0.20 mm | **0.100 mm** | `+3V3` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/BAT_PROTECTED_P` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/BAT_SENSE` |
| 4 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/LTC_GATE` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/LTC_SHDN` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/N_POL` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/Q3_CS` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/REF_HO` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/REF_POL` |
| 2 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/USB_VBUS_RAW` |
| 4 | 0.40 mm | 0.20 mm | **0.100 mm** | `/01_POWER_TREE/VREC_VCC` |
| 5 | 0.40 mm | 0.20 mm | **0.100 mm** | `GND` |
| 1 | 0.45 mm | 0.20 mm | **0.125 mm** | `GND` |
| 2 | 0.45 mm | 0.20 mm | **0.125 mm** | `Net-(U11-TS_MR)` |

J3 USB-C locating holes: two 0.65 mm NPTH pegs have a 0.1944 mm distance to
their own connector contacts. Please confirm this vendor land pattern.
Clearance from those NPTH pegs to other routed copper is >=0.200 mm.
MK1 microphone acoustic port: 1.05 mm unplated hole concentric with a 1.65 mm
GND land, leaving a 0.30 mm annulus. Do not plate, fill or tent the acoustic port.

3. Filled and capped vias
129 distinct barrels intersect 134 solderable lands across 77 components.
Resin-fill, planarize and copper-cap all listed sites to leave solderable lands.
See Via_In_Pad_Sites.csv. Applying this process to all vias is acceptable.
The microphone acoustic hole is excluded from via filling.

Two optional NFC tuning terminals must also be filled/capped and remain
solderable on B.Mask, with F.Mask tented:
GND vias at (43.500,26.700) and (43.500,33.300), diameter/drill 0.60/0.30.
Their copper-edge gap to C71.2/C72.2 is 0.325 mm. Do not close these B.Mask openings.

4. Solder mask and stencil
Supplied mask expansion is 0.000 mm. Please do not apply a default expansion.
The measured mask openings below need process confirmation:

| dam | layer | A | B | same net | declared bridge |
| --- | --- | --- | --- | --- | --- |
| **-0.0500 mm** | B.Mask | `MK1.` | `MK1.4` | **no** | yes |
| **0.0000 mm** | F.Mask | `J3.A1` | `J3.B12` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A12` | `J3.B1` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A4` | `J3.B9` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A9` | `J3.B4` | yes | no |
| **0.1200 mm** | B.Mask | `U12.1` | `U12.2` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.10` | `U12.11` | yes | no |
| **0.1200 mm** | B.Mask | `U12.11` | `U12.12` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.12` | `U12.13` | yes | no |
| **0.1200 mm** | B.Mask | `U12.13` | `U12.14` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.2` | `U12.3` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.3` | `U12.4` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.4` | `U12.5` | yes | no |
| **0.1200 mm** | B.Mask | `U12.5` | `U12.6` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.6` | `U12.7` | yes | no |
| **0.1200 mm** | B.Mask | `U12.8` | `U12.9` | yes | no |
| **0.1200 mm** | B.Mask | `U12.9` | `U12.10` | **no** | no |

USB-C same-net pad pairs and the microphone port-ring opening are intentional.
For U12's different-net 0.120 mm webs, advise whether they can be retained.
Any proposed gang opening or other mask change must be shown for written approval.
Stencil apertures remain separate per pad; do not merge paste apertures.

5. Plated routed slots
Preserve all four Excellon G85 slots as plated slots:

| plating | file | width mm | length mm | centre (x, y) mm | pad |
|---|---|---|---|---|---|
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.700 | (38.680, 144.220) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.400 | (38.680, 148.400) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.700 | (47.320, 144.220) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.400 | (47.320, 148.400) | `J3.SH` |

6. Placement
Use aqroot-Demo-pos-fitted.csv. There are 251 fitted references: 83 top, 168 bottom.
The all-placement file includes DNPs and is not the assembly population list.
X increases right; Y increases upward and is negative across this board.
Rotation is counterclockwise. Bottom-side rotation is viewed from the TOP
through the board (KiCad convention); mirror only if required by your toolchain.
The supplied locator PDFs use a Y-down grid; their reference index lists CPL coordinates.
Return a placement preview for side, rotation and pin-1 approval before assembly.

Use exact approved MPNs. J5: Samtec SSQ-124-02-G-S-RA. U1: ESP32-S3-WROOM-1-N16R8.
Do not fit DNPs or add a header at J4. No accessory reinforcement wire is fitted
between TP12 and J5.3; TP12 and TP25 remain test points.

7. Manual operations and first article
J5 and J6 are post-reflow through-hole operations. D1 TSAL6100 and U6 TSOP38238
require manual optical alignment and lead-forming; the final U6 forming geometry
and enclosure/window alignment are currently under mechanical review.
Do not perform IR forming or final IR installation until a verified assembly
drawing has been issued and approved. Quote these operations separately.

J4 is a manual 26-AWG battery pigtail. See Battery_Harness.json and J4_Work_Instruction.txt.
Inspect the first assembled unit, including X-rays of U11, U9, U12 and the
ESP32 module ground pad, before releasing the remaining assembled unit.

8. Approvals
Provide the proposed stackup, processed production files, routing/panel drawing,
placement preview and any requested deviations for written approval.
Please list any capability limitations, unavailable components or extra charges.
This RFQ does not authorize manufacturing, payment or component procurement.

Pin-1 and polarity reference (CPL coordinates, Y up):

| ref | value | side | CPL rot | pin 1 X | pin 1 Y | pad (function) | pin 1 net |
|---|---|---|---|---|---|---|---|
| `D1` | TSAL6100 | top | 0.000000 | 51.750 | -6.600 | 1 (K) | `/07_IR/IR_LED_K` |
| `D2` | TPD4E1B06DRLR | top | 0.000000 | 58.990 | -24.432 | 1 (IO1) | `/09_COMMUNITY_HEADER/NATIVE_A_HDR` |
| `D4` | TPD4E1B06DRLR | top | 0.000000 | 58.563 | -29.150 | 1 (IO1) | `/09_COMMUNITY_HEADER/XGPIO4_HDR` |
| `D5` | TPD4E1B06DRLR | top | 0.000000 | 58.758 | -21.178 | 1 (IO1) | `unconnected-(D5-IO1-Pad1)` |
| `D8` | NSR0240 | bottom | 0.000000 | 4.700 | -122.750 | 1 (K) | `/03_SPI_A_DISPLAY_SD/LED_BOOST` |
| `D9` | PMEG2010AEH | bottom | 0.000000 | 11.600 | -72.500 | 1 (K) | `/01_POWER_TREE/BAT_PROTECTED_P` |
| `D10` | BAT54WS | bottom | 0.000000 | 10.950 | -30.000 | 1 (K) | `/01_POWER_TREE/VBRIDGE_TOP` |
| `D11` | BAT54WS | bottom | 0.000000 | 14.450 | -30.000 | 1 (K) | `/01_POWER_TREE/VREF_TOP` |
| `D12` | BAT54WS | bottom | 0.000000 | 10.950 | -17.000 | 1 (K) | `/01_POWER_TREE/BAT_RAW` |
| `D13` | MHPA3528RGBCT | top | 0.000000 | 31.060 | -107.675 | 1 (A) | `+3V3` |
| `D14` | BAT54WS | bottom | -90.000000 | 6.800 | -116.850 | 1 (K) | `/03_SPI_A_DISPLAY_SD/BL_DISC_G` |
| `J1` | FH69-50S-0.5SH | top | 0.000000 | 44.910 | -96.000 | 1 (LEDA) | `/03_SPI_A_DISPLAY_SD/LED_A` |
| `J2` | Molex_5025700893 | top | 180.000000 | 17.806 | -146.888 | 1 (DAT2) | `no net` |
| `J3` | USB_C_Receptacle_USB2.0_16P | top | 0.000000 | 39.800 | -143.645 | A1 (GND_A1) | `GND` |
| `J5` | COMMUNITY_PORT_1x24 | top | -90.000000 | 65.900 | -10.000 | 1 (Pin_1) | `/ACC_5V_SW` |
| `J6` | JST-PH-2 SPEAKER | top | 0.000000 | 38.000 | -128.000 | 1 (Pin_1) | `/06_AUDIO/SPK_P_CONN` |
| `J7` | BM02B-ACHSS-GAN-ETF | bottom | 0.000000 | 53.400 | -31.875 | 1 (Pin_1) | `/04_SPI_B_RADIOS_NFC/NFC_ANT_A` |
| `J8` | QWIIC_STEMMA_QT | top | 90.000000 | 71.400 | -77.900 | 1 (Pin_1) | `GND` |
| `MK1` | DMM-4026-B-I2S | bottom | 0.000000 | 2.925 | -99.580 | 1 (LR) | `GND` |
| `Q1` | AO3400A | top | 0.000000 | 46.350 | -1.683 | 1 (G) | `/07_IR/IR_GATE` |
| `Q2` | AO4800 | bottom | 90.000000 | 5.705 | -51.475 | 1 (S1) | `/01_POWER_TREE/Q2_CS` |
| `Q3` | AO4800 | bottom | 90.000000 | 5.705 | -59.275 | 1 (S1) | `/01_POWER_TREE/Q3_CS` |
| `Q4` | BSS138 | bottom | 0.000000 | 1.637 | -94.205 | 1 (G) | `/01_POWER_TREE/BAT_PROT_SHDN_CTL` |
| `Q5` | AO3401A | bottom | 0.000000 | 1.637 | -25.415 | 1 (G) | `/01_POWER_TREE/REC_GATE_N` |
| `Q6` | BSS138 | bottom | 0.000000 | 1.637 | -21.625 | 1 (G) | `/01_POWER_TREE/REC_POL_OK` |
| `Q7` | BSS138 | bottom | 0.000000 | 1.637 | -17.835 | 1 (G) | `/01_POWER_TREE/REC_BAT_LOW` |
| `Q8` | BSS138 | bottom | 0.000000 | 1.637 | -14.045 | 1 (G) | `/01_POWER_TREE/REC_FAULT_B` |
| `Q9` | BSS138 | bottom | 0.000000 | 1.637 | -10.255 | 1 (G) | `/01_POWER_TREE/LTC4368_FAULT_N` |
| `Q10` | 2N7002 | top | 0.000000 | 59.658 | -114.776 | 1 (G) | `/ACC_3V3_SW` |
| `Q11` | SQ2364EES-T1_BE3 | bottom | 0.000000 | 9.363 | -113.450 | 1 (G) | `/03_SPI_A_DISPLAY_SD/BL_DISC_G` |
| `U1` | ESP32-S3-WROOM-1 | top | -90.000000 | 63.010 | -119.250 | 1 (GND) | `GND` |
| `U2` | PCAL9535APW | bottom | 0.000000 | 54.138 | -91.575 | 1 (~{INT}) | `/WAKE_INT_N` |
| `U3` | PCAL9535APW | bottom | 0.000000 | 54.138 | -81.575 | 1 (~{INT}) | `/WAKE_INT_N` |
| `U4` | BMI270 | bottom | -90.000000 | 56.750 | -68.838 | 1 (SDO) | `/05_I2C_DEVICES/BMI270_SDO_ADDR` |
| `U5` | MAX98357A | top | 0.000000 | 29.562 | -115.250 | 1 (DIN) | `/I2S_SPK_DOUT` |
| `U6` | TSOP38238 | top | 0.000000 | 64.210 | -4.600 | 1 (OUT) | `/IR_RX_GPIO44` |
| `U7` | E07-400M10S | bottom | 0.000000 | 34.000 | -127.000 | 1 (GND) | `GND` |
| `U8` | E22-900M22S | bottom | 0.000000 | 17.000 | -127.000 | 1 (GND) | `GND` |
| `U9` | ST25R3916-AQET | bottom | 0.000000 | 31.710 | -31.750 | 1 (VDD_IO) | `+3V3` |
| `U10` | USBLC6-2SC6 | top | 0.000000 | 50.263 | -141.750 | 1 (I/O1) | `/01_POWER_TREE/USB_D_CONN_N` |
| `U11` | BQ25185 | bottom | 0.000000 | 66.400 | -78.600 | 1 (SYS) | `/01_POWER_TREE/BQ25185_SYS` |
| `U12` | TPS63020 | bottom | 0.000000 | 68.100 | -96.200 | 1 (VINA) | `/01_POWER_TREE/BQ25185_SYS` |
| `U14` | MAX17048 | bottom | 0.000000 | 1.245 | -83.265 | 1 (CTG) | `GND` |
| `U16` | TCA4307DGKR | bottom | 0.000000 | 57.138 | -55.725 | 1 (EN) | `/ACC_PWR_EN` |
| `U17` | TPS61169DCKR | bottom | 0.000000 | 1.363 | -123.250 | 1 (SW) | `/03_SPI_A_DISPLAY_SD/BL_SW` |
| `U18` | LTC4368-1 | bottom | 180.000000 | 10.100 | -65.500 | 1 (VIN) | `/01_POWER_TREE/BAT_RAW` |
| `U19` | TLV7032 | bottom | 0.000000 | 1.558 | -29.230 | 1 (OUTA) | `/01_POWER_TREE/REC_POL_OK` |
| `U20` | TPS22950-Q1 | bottom | 180.000000 | 53.388 | -63.800 | 1 (ON) | `/ACC_3V3_EN` |
| `U21` | TPS61023 | bottom | 0.000000 | 57.087 | -40.400 | 1 (FB) | `/01_POWER_TREE/ACC_5V_FB` |
| `U22` | TPS22950-Q1 | bottom | 0.000000 | 53.862 | -43.950 | 1 (ON) | `/ACC_5V_SW_EN` |
| `Y1` | 27.12MHz 10pF 3225-4P | bottom | 180.000000 | 29.400 | -30.850 | 1 (1) | `/04_SPI_B_RADIOS_NFC/NFC_XOUT` |
