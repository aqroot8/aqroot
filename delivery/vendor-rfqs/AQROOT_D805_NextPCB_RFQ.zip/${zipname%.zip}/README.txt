AQROOT D-805 — NextPCB PROTOTYPE PCB / PCBA RFQ

Purpose: engineering review and quotation only.
Requested build: 2 fully assembled PCBAs. If bare-board fabrication has a higher minimum quantity, quote the minimum bare-board quantity and assemble 2 units.

This package is NOT authorization to fabricate or assemble.

Please review RFQ_REQUIREMENTS.txt and AQROOT_D805_Fabrication_Notes.md before quoting. Do not alter copper, pads, drills, plated slots, solder mask, paste, footprint locations, or board outline without written approval.

The Portal_Upload_Files folder contains files formatted for the vendor portal. The complete Gerbers and manufacturing documentation remain the technical authority.
