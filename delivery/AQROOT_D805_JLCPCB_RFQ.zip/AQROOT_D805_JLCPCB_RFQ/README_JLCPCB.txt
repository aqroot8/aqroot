AQROOT D-805 — JLCPCB PCB/PCBA RFQ PACKAGE

Requested build:
- 5 bare PCBs (JLCPCB online fabrication minimum shown for this quote flow)
- 2 fully assembled PCBAs
- Standard PCBA, both sides
- JLCPCB manual component matching requested
- Exact manufacturer part numbers unless written substitution approval is given

Online PCB configuration prepared:
- FR-4, 6 layers
- S1000H Tg155
- 1.6 mm nominal thickness
- ENIG
- 1 oz outer copper / 0.5 oz inner copper
- 0.20 mm minimum via hole class
- Epoxy filled & capped via process
- Flying-probe full electrical test
- Production files require manual customer approval

See RFQ_REQUIREMENTS.txt and AQROOT_D805_Fabrication_Notes.md for special process and CAM requirements.
This package is for quotation/DFM/DFA review only and does not authorize fabrication or assembly.
