## J2 microSD routed-edge clearance — quote/CAM confirmation required

The two mechanical shell lands of J2 (Molex 5025700893) are approximately **0.213 mm from the routed board edge** at the J2 bottom tab. This geometry is intentional in this D-805 quotation package and is covered by the design rule used for this footprint. **Before fabrication, confirm in writing that your process can manufacture the supplied 0.213 mm shell-land-to-routed-edge clearance. Do not trim, move, or reduce these lands without written approval.** If your process requires a larger value, stop and state the minimum required clearance.

# AQROOT Demo - FABRICATION NOTES

from the board this package was built from.  Every number below is read out of the board or its `.kicad_dru` at generation time.

## Drill-to-copper clearance

Global board minimum hole clearance: **0.250 mm**.

KiCad DRC on this board reports **ZERO** `hole_clearance` violations.  3 named, footprint-scoped rules accept the clearances below, and NOTHING else on the board is affected:

### `FP-J3 USB4105 land pattern - its own NPTH pegs vs its own pads, D-677`

- accepted minimum: **0.150mm**
- scope: `A.Type == 'Pad' && B.Type == 'Pad' && A.memberOfFootprint('J3') && B.memberOfFootprint('J3')`
- GCT USB4105-xx-A USB-C receptacle, vendor land pattern (footprint verified MATCH against the GCT series drawing).  Its two Oe0.65 mm NPTH locating pegs stand 0.1944 mm from its own GND contacts A1 / B12 / A12 / B1.  BOTH the hole and the copper are the manufacturer's and neither can move without diverging from the library master.  0.1944 mm is 5.6 um BELOW a 0.200 mm NPTH-to-copper process reference: PLEASE CONFIRM, and advise if your process needs the pads trimmed.

### `FP-MK1 DMM-4026 acoustic port inside its own GND annulus - D-227 construction, D-677`

- accepted minimum: **0.000mm**
- scope: `A.Type == 'Pad' && B.Type == 'Pad' && A.memberOfFootprint('MK1') && B.memberOfFootprint('MK1')`
- PUI DMM-4026-B-I2S bottom-port MEMS microphone.  The Oe1.05 mm acoustic port is an UNPLATED hole drilled concentrically through its own Oe1.65 mm GND land, leaving a 0.30 mm annulus -- this is intentional (the land is what the microphone's port seals against) and there is no plated through-hole here.  Copper IS exposed in the barrel wall; no plating or tenting is required.

### `FP-J3 NPTH locating peg vs foreign copper - 0.200 mm process reference`

- accepted minimum: **0.200mm**
- scope: `(A.Pad_Type == 'NPTH, mechanical' && A.memberOfFootprint('J3') && !B.memberOfFootprint('J3')) || (B.Pad_Type == 'NPTH, mechanical' && B.memberOfFootprint('J3') && !A.memberOfFootprint('J3'))`
- Routed GND copper approaches J3's NPTH pegs no closer than 0.2100 mm (tracks) and 0.2412 mm (one 0.50/0.20 mm via), i.e. at or above the published 0.200 mm NPTH-to-track figure.  The peg is the receptacle's metal shell leg and the shell is tied to GND through R32 (0 ohm), so this copper is already at the peg's own potential.

## Board outline -- STEPPED PROFILE, READ THIS BEFORE ROUTING

Profile extents: **77.000 x 151.000 mm** (x 0.000 .. 77.000, y 0.000 .. 151.000), 16 segments.  It also carries **8 arcs**: 4 drawn INSIDE fillets and 4 rounded outside corners.

**DRAWN INSIDE FILLETS (D-805).**  These inside corners are drawn as arcs, so the router must FOLLOW the drawn radius: a tool radius above it leaves material inside the drawn fillet (the board grows there), and any plunge or relief below it removes material toward copper.  Each is also inside the 1.00 mm retained-fillet bound stated below.

- drawn inside fillet **r 1.000 mm** centred at (5.000, 149.000) -- tool radius <= 1.000 mm; nearest copper to the fillet is **2.526 mm** away, edge to edge (pad J2.9, `GND`).
- drawn inside fillet **r 1.000 mm** centred at (25.000, 149.000) -- tool radius <= 1.000 mm; nearest copper to the fillet is **1.193 mm** away, edge to edge (track, `/SPI_B_SCK`).
- drawn inside fillet **r 1.000 mm** centred at (35.500, 149.000) -- tool radius <= 1.000 mm; nearest copper to the fillet is **1.193 mm** away, edge to edge (track, `/SPI_B_SCK`).
- drawn inside fillet **r 1.000 mm** centred at (50.500, 149.000) -- tool radius <= 1.000 mm; nearest copper to the fillet is **1.193 mm** away, edge to edge (track, `/SPI_B_SCK`).

The profile has **2 INSIDE (reflex) corners**.  A profile router cannot cut a sharp inside corner: it leaves a fillet of its own tool radius, which means **MATERIAL REMAINS** and the board is very slightly LARGER there than drawn.  A retained fillet is the CORRECT treatment.  What is NOT accepted is squaring the corner by plunging, drilling a relief or otherwise OVER-CUTTING, because that removes material toward the copper.

**D-788 / R7-D787-13 BOUNDS THE RETAINED FILLET.**  This note previously said *"any tool radius is fine and the enclosure clears it"*, which is an unbounded permission: material left by a large tool grows the board OUTWARD at the step, and the enclosure recess it has to sit in has **1.500 mm** of inside radius at that step.  The bound is therefore stated in both directions, and CAM must show it before the profile is cut:

- **MAXIMUM RETAINED FILLET / TOOL RADIUS: 1.00 mm.**  A larger tool leaves material that the enclosure recess does not clear.  A 1.00 mm or smaller routing tool satisfies it; so does any larger tool that finishes the corner with a 1.00 mm or smaller radius.
- **NO OVER-CUT.**  Any corner relief must stay under the per-corner copper distance listed below.
- **CAM PROFILE PREVIEW IS REQUIRED.**  The fabricator must return a profile/rout preview showing the ACTUAL retained corner geometry and the tool radius used, and it must be accepted in writing before the profile is cut.  Silent over-cut and silent over-size are both refusals.

- inside corner at **(72.000, 104.005)** -- nearest copper is **0.941 mm** away, edge to edge (pad R41.2, `Net-(U12-PG)`).  A corner relief must stay under 0.941 mm of radius; **a 1.0 mm relief would reach copper here**.
- inside corner at **(72.000, 70.500)** -- nearest copper is **0.726 mm** away, edge to edge (track, `Net-(U11-TS_MR)`).  A corner relief must stay under 0.726 mm of radius; **a 1.0 mm relief would reach copper here**.

Board copper-to-edge minimum in force: **0.500 mm**, and KiCad DRC on this board reports ZERO `copper_edge_clearance` violations.

## Vias in solderable lands -- VIA PROTECTION IS REQUIRED

Solder-mask expansion on this board is **0.000 mm**, so a pad's mask aperture IS its copper.  **129 via barrels open directly into 134 solderable lands across 77 components**, on hole sizes 0.20 mm / 0.25 mm / 0.30 mm / 0.40 mm.  134 of those lands carry the SAME net as the via, which is why no clearance check and no KiCad DRC rule reports them -- KiCad has no via-in-pad rule at all.

**REQUIRED PROCESS: these vias must be PLUGGED / RESIN-FILLED AND CAP-PLATED (via-in-pad / POFV), or filled by an equivalent process that leaves a planar, solderable land.**  Applying the process to every via on the board is acceptable and is the simpler instruction; what is NOT acceptable is shipping these barrels open.

Why it is not optional, in this board's own numbers: the largest hole in a land is **0.40 mm**, and through 1.60 mm of finished board that barrel holds **0.201 mm3**.  A 0.12 mm stencil over the 0.560 x 0.620 mm land it sits in deposits about **0.042 mm3** of paste.  **The barrel can swallow the whole deposit.**

The ten worst lands, by how much of the land is open hole:

| land | layer | land size (mm) | hole | open area | % of land | net |
| --- | --- | --- | --- | --- | --- | --- |
| `C18.1` | B.Cu | 0.560 x 0.620 | 0.40 mm | 0.1255 mm2 | **38.2 %** | `+3V3` |
| `D8.1` | B.Cu | 0.600 x 0.450 | 0.30 mm | 0.0625 mm2 | **24.2 %** | `/03_SPI_A_DISPLAY_SD/LED_BOOST` |
| `J1.8` | F.Cu | 0.300 x 1.230 | 0.40 mm | 0.0786 mm2 | **21.3 %** | `+3V3` |
| `J1.25` | F.Cu | 0.300 x 1.230 | 0.30 mm | 0.0699 mm2 | **18.9 %** | `GND` |
| `J1.31` | F.Cu | 0.300 x 1.230 | 0.30 mm | 0.0653 mm2 | **17.7 %** | `GND` |
| `R25.1` | F.Cu | 0.800 x 0.950 | 0.40 mm | 0.1253 mm2 | **17.3 %** | `+3V3` |
| `R91.1` | B.Cu | 0.800 x 0.950 | 0.40 mm | 0.1158 mm2 | **16.0 %** | `/01_POWER_TREE/USB_VBUS_CHG` |
| `C56.1` | F.Cu | 0.900 x 0.950 | 0.40 mm | 0.1255 mm2 | **15.5 %** | `+3V3` |
| `C8.1` | F.Cu | 0.900 x 0.950 | 0.40 mm | 0.1255 mm2 | **15.5 %** | `+3V3` |
| `C39.1` | B.Cu | 0.900 x 0.950 | 0.40 mm | 0.1097 mm2 | **13.6 %** | `/ACC_3V3_SW` |

**31 of the 134 lands are FINE-PITCH** (one land dimension at or below 0.500 mm) -- including D8.1, J1.12, J1.14, J1.16, J1.18, J1.22, J1.23, J1.25.  On those the hole is a large fraction of the land's width and an unfilled barrel does not merely starve the joint, it removes the land.

The complete list of barrel centres is in `MANIFEST.json` under `via_in_pad`.

## Via geometry -- SUB-FLOOR VIAS, PLEASE CONFIRM

This board's own `.kicad_dru` floor is **annular ring >= 0.125 mm** and its board setup asks **>= 0.500 mm of via diameter**.  **38 vias sit below one or both**, at annular rings 0.075 mm / 0.125 mm.  Each is licensed inside the design by a NAMED, net-scoped, area-enclosed `.kicad_dru` rule (the `FINE_ESC_*`, `*_POFV`, `*_KELVIN` and `BAT_PROT_TAP_*` rule areas), so real KiCad DRC passes them -- but that is an INTERNAL licence and it is not a fabricator's agreement.  **Please confirm you can hold these, and advise if your process needs the pads grown.**

| count | via dia | drill | annular ring | net |
| --- | --- | --- | --- | --- |
| 6 | 0.35 mm | 0.20 mm | **0.075 mm** | `+3V3` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/BAT_PROTECTED_P` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/BAT_SENSE` |
| 4 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/LTC_GATE` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/LTC_SHDN` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/N_POL` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/Q3_CS` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/REF_HO` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/REF_POL` |
| 2 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/USB_VBUS_RAW` |
| 4 | 0.35 mm | 0.20 mm | **0.075 mm** | `/01_POWER_TREE/VREC_VCC` |
| 5 | 0.35 mm | 0.20 mm | **0.075 mm** | `GND` |
| 1 | 0.45 mm | 0.20 mm | **0.125 mm** | `GND` |
| 2 | 0.45 mm | 0.20 mm | **0.125 mm** | `Net-(U11-TS_MR)` |

All of them are ORDINARY THROUGH vias -- this board carries no blind via, no buried via and no laser microvia, and its `.kicad_dru` disallows all three explicitly.

## Solder-mask dams -- MEASURED HERE, NOT BY DRC

**`solder_mask_min_width` in this board's setup is 0.000 mm, which switches KiCad's `solder_mask_bridge` test OFF.**  A clean DRC report therefore says NOTHING about mask webs on this board, and the webs below were measured for this note instead -- polygon to polygon, not bounding box.  `pad_to_mask_clearance` is 0.000 mm, so an aperture is its pad.  UNTENTED VIA CAPS are apertures too and are surveyed here as well (D-757); every other via on this board is tented on both masks.

Every dam below **0.125 mm** on the board:

| dam | layer | A | B | same net | declared bridge |
| --- | --- | --- | --- | --- | --- |
| **-0.0500 mm** | B.Mask | `MK1.` | `MK1.4` | **no** | yes |
| **0.0000 mm** | F.Mask | `J3.A1` | `J3.B12` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A12` | `J3.B1` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A4` | `J3.B9` | yes | no |
| **0.0000 mm** | F.Mask | `J3.A9` | `J3.B4` | yes | no |
| **0.1200 mm** | B.Mask | `U12.1` | `U12.2` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.10` | `U12.11` | yes | no |
| **0.1200 mm** | B.Mask | `U12.11` | `U12.12` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.12` | `U12.13` | yes | no |
| **0.1200 mm** | B.Mask | `U12.13` | `U12.14` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.2` | `U12.3` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.3` | `U12.4` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.4` | `U12.5` | yes | no |
| **0.1200 mm** | B.Mask | `U12.5` | `U12.6` | **no** | no |
| **0.1200 mm** | B.Mask | `U12.6` | `U12.7` | yes | no |
| **0.1200 mm** | B.Mask | `U12.8` | `U12.9` | yes | no |
| **0.1200 mm** | B.Mask | `U12.9` | `U12.10` | **no** | no |
| **0.1243 mm** | B.Mask | `U9.1` | `U9.32` | **no** | no |
| **0.1243 mm** | B.Mask | `U9.16` | `U9.17` | **no** | no |
| **0.1243 mm** | B.Mask | `U9.24` | `U9.25` | **no** | no |
| **0.1243 mm** | B.Mask | `U9.8` | `U9.9` | **no** | no |

**What each group is, and what is being asked.**

- Rows marked *same net* are vendor land patterns whose two contacts are one node -- the USB-C receptacle's A/B pairs are the whole of that group.  A merged aperture there is harmless and no action is requested.
- Rows marked *declared bridge* carry `allow_soldermask_bridges` on the footprint AND on its library master; the microphone's port ring is the whole of that group and the merge is the design.
- **The remaining 11 rows are DIFFERENT NETS.**  All of them are MANUFACTURER LAND PATTERNS, not routing.  **None is at or under 0.100 mm.**  **11 are between 0.100 and 0.130 mm** (`U12` 7 pairs at 0.1200 mm; `U9` 4 pairs at 0.1243 mm), AT the usual 0.100-0.130 mm web limit rather than under it: **print the web if you can hold it, gang the pair if you cannot, and tell us which.**  Assembly control at every one of these pitches is the PASTE stencil, which is per-pad and is unaffected either way.

## NFC first-article parallel-match access -- DO NOT TENT

Two GND vias are intentional **solderable tuning terminals** for optional 0402 parallel-match capacitors from the ST25R3916 match nodes.  These two vias MUST receive the same **RESIN-FILL, PLANARIZE, COPPER-CAP** process as POFV lands and their **B.Mask openings MUST remain exposed**.  F.Mask remains tented.  Do not retent them during CAM cleanup.

- **A side:** `C71.2` (`/04_SPI_B_RADIOS_NFC/NFC_MATCH_A`) -> GND via at **(43.500, 26.700) mm**, 0.60/0.30 mm via, copper-edge gap **0.325 mm**; B.Mask OPEN, F.Mask tented.
- **B side:** `C72.2` (`/04_SPI_B_RADIOS_NFC/NFC_MATCH_B`) -> GND via at **(43.500, 33.300) mm**, 0.60/0.30 mm via, copper-edge gap **0.325 mm**; B.Mask OPEN, F.Mask tented.

Assembly tuning is optional; **manufacturing access is not**. The board must arrive with both capped GND terminals solderable even if no parallel capacitor is fitted initially.

## J4 battery pigtail -- MANUAL ASSEMBLY, NO PCB HEADER

`J4` is a 2-hole manual wire land in this release. **Do not fit the old JST-PH board header.**
The authoritative detachable-harness record is `aqroot-Demo-BATTERY-HARNESS.json` in this package.

- Board side: **26 AWG**; exact pre-crimps `2175012101` / `2175011101`; housing `5055700201`.
- Battery side: Adafruit 328 factory lead **26 AWG**; Micro-Lock plug `2137192021`, male terminal `2137201000`.
- Controlling mated-harness rating: **2.6 A at AWG26**.
- Polarity: cavity 1 = **BAT+ / red / J4.1**; cavity 2 = **GND / black / J4.2**.
- J4 is drilled **0.75 mm nominal**. Supplier/assembler must guarantee a **>=0.70 mm finished plated-hole diameter** for both J4 barrels; verify one exact 217501 AWG26 tinned lead passes freely before soldering all five boards -- no force and no strand shaving.
- Insert the tinned conductors from the rear (`B.Cu`), apply solder and inspect barrel fill from the front (`F.Cu`); keep the front conductive profile **<=0.50 mm**, then **<=0.10 mm polyimide** before display fit. Follow `THT_LEAD_TRIM.md` J4-T1..T4.
- Rear strain relief: **DOWSIL 3145 RTV MIL-A-46146 Adhesive/Sealant, gray**. After joint/profile inspection and cleaning, apply the frozen adhesive fillet to the insulated pigtail, preserve the >=35 mm housing free-wire/service-loop rule, and never unplug by pulling wires.
- First article: verify finished-hole/conductor fit, cured strain relief, DMM polarity, terminal retention/pull acceptance, housing-only disconnect, enclosure route, and worst-case load temperature rise per the packaged harness record.

## ACC_3V3 Community-Port reinforcement -- **NONE.  NOTHING TO DO.**

**THERE IS NO MANUAL ACCESSORY-VOLTAGE CONDUCTOR ON THIS BOARD.**  Both duplicated Community-Port 3.3 V contacts are delivered by ROUTED COPPER ALONE.  If a build instruction, a work order or an older revision of this package tells you to solder a wire from `TP12` to `J5.3`, it is superseded -- do not do it.

- Delivered by routed copper: **J5.3 (routed copper alone, 224.4 mOhm measured, bounded at 240), J5.22 (routed copper alone, 79.0 mOhm measured, bounded at 90)**.
- `TP12` and `TP25` remain on the board as TEST POINTS on `/ACC_3V3_SW`, downstream of `U20`, for bring-up measurement and for a future rework.  **Nothing is soldered to them.**
- `U20` TPS22950-Q1 current limiting and OFF isolation are unchanged and remain in series with both contacts.
- Published delivery, DERIVED by `demo_feature_contract` F6 over every wiring and load case: **2.805637 V** at the full 400 mA in the worst SIZING case (one 3.3 V contact alone, one mated ground, the 5 V rail also at its full 300 mA budget), and **2.910494 V** with the header fully mated.  The 400 mA + 300 mA pair is a SIZING case, NOT a permitted mode: both rails together are admitted only at the declared 220 mA + 170 mA pair, and no accessory rail is admitted while a radio transmits (D-796).
- Why it was retired, in one line each: the `TP12` tip geometry could not be built inside a 1.00 mm pad; the `J5.3` termination required inserting a 0.32 mm conductor into a 1.02 mm hole already carrying a 0.635 mm square tail; the route started inside `BATTERY_SHADOW` and crossed `RIB_R3` against its own clearance rule; and its <= 25 mOhm acceptance could not be measured with the board's own copper in parallel.  The full record is `aqroot-Demo-ACC-3V3-REINFORCEMENT.json` in this package.
- First article: **C-ACC-01** measures the delivered potential at the J5 mating interface for each contact alone and for the fully mated header -- SIZING / DIAGNOSTIC readings (400 mA single-rail, and the 400 mA + 300 mA shared-ground sizing case held only for the reading), NOT operating modes: both rails together are supported only at the declared 220 mA + 170 mA pair (D-803); **C-ACC-02** records the two routed resistances.

## Stackup, finish and required process -- NOT SUBSTITUTABLE

Everything below is read out of the board file's own stackup block and is also carried machine-readably in `aqroot-Beta-v2-job.gbrjob` (Gerber X2 `MaterialStackup`).  It is repeated here because a quote taken against a house default would be wrong in ways nothing downstream catches.

| layer | type | thickness (mm) | material |
|---|---|---|---|
| `F.Mask` | Top Solder Mask | **0.0100** |  |
| `F.Cu` | copper | **0.0350** |  |
| `dielectric 1` | prepreg | **0.2104** | 7628 |
| `In1.Cu` | copper | **0.0152** |  |
| `dielectric 2` | core | **0.4000** | FR4 |
| `In2.Cu` | copper | **0.0152** |  |
| `dielectric 3` | prepreg | **0.2028** | 7628 |
| `In3.Cu` | copper | **0.0152** |  |
| `dielectric 4` | core | **0.4000** | FR4 |
| `In4.Cu` | copper | **0.0152** |  |
| `dielectric 5` | prepreg | **0.2104** | 7628 |
| `B.Cu` | copper | **0.0350** |  |
| `B.Mask` | Bottom Solder Mask | **0.0100** |  |

- **6 copper layers.**  Finished outer copper **0.0350 mm**; **inner copper 0.0152 mm on all 4 inner layers.**
- **THE INNER COPPER THICKNESS IS LOAD-BEARING, NOT INCIDENTAL.**  `audit_rail_ampacity` sizes every power rail on this board against **0.0152 mm** of inner foil.  A build substituted to a heavier or lighter inner foil INVALIDATES that model and the ampacity audit must be re-run before the order is placed.
- **Total declared stack 1.5744 mm; required finished thickness 1.5744 +/- 0.10 mm.**  Do not substitute a house-default thickness without written engineering approval.  `J4` is now a manual pigtail land: its front conductive profile is MEASURED <=0.50 mm after soldering, not inferred from board thickness.  Finished thickness still affects enclosure stack and PTH process capability.
- **Board thickness on the order: 1.6 mm nominal** (the value the board file's general section and `aqroot-Beta-v2-job.gbrjob` carry, and the nominal of the declared stack); the ACCEPTANCE figure is the stack's own **1.5744 mm +/- 0.10 mm** above -- the two are the same board, not a conflict.
- **Surface finish: ENIG -- not substitutable.**  HASL coplanarity is incompatible with the fine-pitch lands on this board and with the 0.000 mm solder-mask expansion it is drawn with.
- **Solder-mask expansion is 0.000 mm board-wide** -- a pad's mask aperture IS its copper.  Do not apply a house expansion.
- **LAMINATE: FR4 with Tg >= 150 C -- D-788 / R7-D787-04, restated at D-789 / D788-03 and RE-JUSTIFIED at D-790 / D789-A02.**  The board file declares FR4 and nothing more, and a house TG130 default is not an acceptable substitution.  TWO SENTENCES THIS NOTE USED TO CARRY ARE WITHDRAWN.  D-788 called 105 C "the laminate's maximum continuous operating temperature"; nothing in this repository publishes an MOT for a Tg-150 FR4, so that claimed a specification it did not have.  105 C is a DECLARED CONDUCTOR-SIZING limit in `audit_rail_ampacity` for copper heated by its own current, and the named narrow-run exceptions meet it with more than 50 K to spare (the `U11.2` package-land neck reaches a 52.3 C predicted peak).  D-789 D-789's own Tg justification -- a BQ25185 junction computed with TI's JEDEC RthetaJA referenced to the EXTERNAL ambient -- is RETIRED: a JEDEC thermal resistance is measured in OPEN STILL AIR, which this sealed 85 x 160 x 23 mm enclosure is not.  D-790 replaced it with TJ = TA + R_SYS x P_internal + thetaJA x P_U11, where R_SYS is the enclosure's own declared 3.25 K/W and P_internal also carries the UPSTREAM losses -- the four pass-pair channels, R75, F1 and the pack's own PCM and harness, all of which are under the same lid.  WHAT THE Tg REQUIREMENT ACTUALLY PROTECTS is the hottest point on this board, which is that junction.

  - At the DECLARED SUSTAINED THERMAL ENVELOPE -- the 1.7745 A battery current this enclosure supports indefinitely at the 40 C top of the ambient range -- the junction reaches **102.16 C**, against TI's own 125 C operating maximum and 47.84 K below a 150 C Tg.  THIS is the figure the Tg requirement is justified against.  It is a SIZING envelope -- a battery current, not a state a user or a technician puts the product in (D-795).
  - At the PEAK ELECTRICAL ENVELOPE -- every internal subsystem at its published maximum with both accessory rails at their published budgets, concurrently, which is the CONDUCTOR-SIZING and PROTECTION-ORDERING basis and is NOT a steady state -- the same model gives **178.42 C** at the 2.7 A the copper is sized for.  That is above TI's 125 C operating maximum AND above its 150 C thermal shutdown, which is exactly why the sustained envelope is derived and published separately and why `demo_feature_contract` F12 proves the cell-to-load network CANNOT HOLD the peak envelope as an operating point.  A board that could sit there would shut its charger down; this one cannot get there.  (D-790 printed 142.8 C here; the itemised upstream path of R11-07 and the missing ESP32-S3 baseline of R11-02 have since raised it, and D-794 / R13-06 DERIVES it here rather than repeating a literal.)
  - Both figures EXCLUDE the accepted narrow run's own copper dissipation, which enters the same package through the same pin; `audit_rail_ampacity`'s `BAT_PROTECTED_P` row adds it and is the RULING figure.  A TG130 build has no margin at either and is refused.  State the laminate and its Tg on the acknowledgement, and see `C-THERM-01`, which MEASURES R_SYS rather than assuming it.
- **100% BARE-BOARD ELECTRICAL TEST (flying probe or fixture) IS REQUIRED ON EVERY DELIVERED PCB CIRCUIT, against the final accepted netlist; panel-level sampling is not sufficient.**  This is a 6-layer board with resin-filled, cap-plated via-in-pad under fine-pitch parts: an open in a filled barrel is not findable at assembly and not repairable after it.  Provide traceable test confirmation with the lot.

## Routed slots (Excellon G85) -- manufacturer acceptance B09

The drill files carry **4 routed slots** as Excellon `G85` moves.  Each is a SLOT, not a round hole, and must be fabricated as one with the plating stated; confirm in the CAM acceptance (B09) that no slot has been re-interpreted as a drilled hole.

| plating | file | width mm | length mm | centre (x, y) mm | pad |
|---|---|---|---|---|---|
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.700 | (38.680, 144.220) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.400 | (38.680, 148.400) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.700 | (47.320, 144.220) | `J3.SH` |
| PLATED | `aqroot-Beta-v2-PTH.drl` | 0.600 | 1.400 | (47.320, 148.400) | `J3.SH` |

## Component placement (CPL) convention -- READ BEFORE PROGRAMMING THE PLACER

`aqroot-Demo-pos-fitted.csv` is the file to place from; `aqroot-Demo-pos-all.csv` additionally carries the DNP references and must NOT be used as the placement list.

- **251 fitted placements: 168 bottom, 83 top.**  The majority of this board is on the BOTTOM side; confirm the panel orientation before the first unit.
- **Origin** is the KiCad page origin, NOT an auxiliary axis: no `aux_axis_origin` is set on this board.  The `Edge_Cuts` outline occupies X -0.050 .. 77.050 mm and Y -0.050 .. 151.050 mm in that frame.
- **`PosX` is millimetres, increasing to the RIGHT.**  Observed range 2.125 .. 75.200 mm.
- **`PosY` is millimetres, increasing UPWARD, and is therefore NEGATIVE across this whole board** (KiCad's internal Y axis points down and the exporter negates it).  Observed range -147.325 .. -2.250 mm.  A toolchain that expects Y-down must negate this column; one that expects Y-up must not.
- **`Rot` is degrees COUNTER-CLOCKWISE**, 0 to 360 normalised to (-180, 180].  Values present on this board: -90 deg, 0 deg, 90 deg, 180 deg.
- **`Rot` for a BOTTOM-side part is given as seen from the TOP of the board, through it** -- the KiCad convention.  An assembler whose process expects bottom-side angles as seen from BELOW must mirror them (negate, or equivalently subtract from 360).  **This is the single most common way this file is misread and it affects 168 of the 251 placements here.**
- **`Side` is the authority on which face a part goes to**; do not infer it from the sign of any coordinate.
- **Polarised and pin-1 references are called out individually in the PIN-1 / POLARITY table below**, generated from the board's own pads (D-800: this line used to point at the first-five plan, which never carried such a list).

> **A placement preview is REQUIRED before the first unit is built.**  Render the loaded CPL against the assembly drawings (`aqroot-Demo-assembly-top.pdf`, `aqroot-Demo-assembly-bottom.pdf`) and confirm side and rotation for at least `U1`, `J1`, `J5`, `U11`, `U12` and `U21` before release to the line. **`J4` is intentionally absent from the CPL at D-781 because it is a manual wire land, not a placed component; verify J4 polarity, rear-wire entry, joint height and strain relief against the battery-harness work instruction instead.**

- **Silkscreen beyond the stepped outline (D-800).**  At `J5`'s right-angle overhang the reference `J5` and two `5V` labels print partly beyond the board edge, where the outline steps in.  They carry no information a builder needs; clip silkscreen at the outline.  This is expected, not a data error.

## PIN-1 / POLARITY TABLE (generated from the board, D-800)

Every fitted, placed `U`, `Q`, `D`, `J`, `Y` and `MK` reference. `pin 1 X/Y` is that pad's centre in the CPL frame above (Y up, negative).  For a diode the pad named here is the one this library numbers 1 -- its function column says which terminal it is.  Check orientation against this table at the placement preview and at AOI.

| ref | value | side | CPL rot | pin 1 X | pin 1 Y | pad (function) | pin 1 net |
|---|---|---|---|---|---|---|---|
| `D1` | TSAL6100 | top | 0.000000 | 51.750 | -6.600 | 1 (K) | `/07_IR/IR_LED_K` |
| `D2` | TPD4E1B06DRLR | top | 0.000000 | 58.990 | -24.432 | 1 (IO1) | `/09_COMMUNITY_HEADER/NATIVE_A_HDR` |
| `D4` | TPD4E1B06DRLR | top | 0.000000 | 58.563 | -29.150 | 1 (IO1) | `/09_COMMUNITY_HEADER/XGPIO4_HDR` |
| `D5` | TPD4E1B06DRLR | top | 0.000000 | 58.758 | -21.178 | 1 (IO1) | `unconnected-(D5-IO1-Pad1)` |
| `D8` | NSR0240 | bottom | 0.000000 | 4.700 | -122.750 | 1 (K) | `/03_SPI_A_DISPLAY_SD/LED_BOOST` |
| `D9` | PMEG2010AEH | bottom | 0.000000 | 11.600 | -72.500 | 1 (K) | `/01_POWER_TREE/BAT_PROTECTED_P` |
| `D10` | BAT54WS | bottom | 0.000000 | 10.950 | -30.000 | 1 (K) | `/01_POWER_TREE/VBRIDGE_TOP` |
| `D11` | BAT54WS | bottom | 0.000000 | 14.450 | -30.000 | 1 (K) | `/01_POWER_TREE/VREF_TOP` |
| `D12` | BAT54WS | bottom | 0.000000 | 10.950 | -17.000 | 1 (K) | `/01_POWER_TREE/BAT_RAW` |
| `D13` | MHPA3528RGBCT | top | 0.000000 | 31.060 | -107.675 | 1 (A) | `+3V3` |
| `D14` | BAT54WS | bottom | -90.000000 | 6.800 | -116.850 | 1 (K) | `/03_SPI_A_DISPLAY_SD/BL_DISC_G` |
| `J1` | FH69-50S-0.5SH | top | 0.000000 | 44.910 | -96.000 | 1 (LEDA) | `/03_SPI_A_DISPLAY_SD/LED_A` |
| `J2` | Molex_5025700893 | top | 180.000000 | 17.806 | -147.038 | 1 (DAT2) | `no net` |
| `J3` | USB_C_Receptacle_USB2.0_16P | top | 0.000000 | 39.800 | -143.645 | A1 (GND_A1) | `GND` |
| `J5` | COMMUNITY_PORT_1x24 | top | -90.000000 | 65.900 | -10.000 | 1 (Pin_1) | `/ACC_5V_SW` |
| `J6` | JST-PH-2 SPEAKER | top | 0.000000 | 38.000 | -128.000 | 1 (Pin_1) | `/06_AUDIO/SPK_P_CONN` |
| `J7` | BM02B-ACHSS-GAN-ETF | bottom | 0.000000 | 53.400 | -31.875 | 1 (Pin_1) | `/04_SPI_B_RADIOS_NFC/NFC_ANT_A` |
| `J8` | QWIIC_STEMMA_QT | top | 90.000000 | 71.400 | -77.900 | 1 (Pin_1) | `GND` |
| `MK1` | DMM-4026-B-I2S | bottom | 0.000000 | 2.925 | -99.580 | 1 (LR) | `GND` |
| `Q1` | AO3400A | top | 0.000000 | 46.350 | -1.683 | 1 (G) | `/07_IR/IR_GATE` |
| `Q2` | AO4800 | bottom | 90.000000 | 5.705 | -51.475 | 1 (S1) | `/01_POWER_TREE/Q2_CS` |
| `Q3` | AO4800 | bottom | 90.000000 | 5.705 | -59.275 | 1 (S1) | `/01_POWER_TREE/Q3_CS` |
| `Q4` | BSS138 | bottom | 0.000000 | 1.637 | -94.205 | 1 (G) | `/01_POWER_TREE/BAT_PROT_SHDN_CTL` |
| `Q5` | AO3401A | bottom | 0.000000 | 1.637 | -25.415 | 1 (G) | `/01_POWER_TREE/REC_GATE_N` |
| `Q6` | BSS138 | bottom | 0.000000 | 1.637 | -21.625 | 1 (G) | `/01_POWER_TREE/REC_POL_OK` |
| `Q7` | BSS138 | bottom | 0.000000 | 1.637 | -17.835 | 1 (G) | `/01_POWER_TREE/REC_BAT_LOW` |
| `Q8` | BSS138 | bottom | 0.000000 | 1.637 | -14.045 | 1 (G) | `/01_POWER_TREE/REC_FAULT_B` |
| `Q9` | BSS138 | bottom | 0.000000 | 1.637 | -10.255 | 1 (G) | `/01_POWER_TREE/LTC4368_FAULT_N` |
| `Q10` | 2N7002 | top | 0.000000 | 59.658 | -114.776 | 1 (G) | `/ACC_3V3_SW` |
| `Q11` | SQ2364EES-T1_BE3 | bottom | 0.000000 | 9.363 | -113.450 | 1 (G) | `/03_SPI_A_DISPLAY_SD/BL_DISC_G` |
| `U1` | ESP32-S3-WROOM-1 | top | -90.000000 | 63.010 | -119.250 | 1 (GND) | `GND` |
| `U2` | PCAL9535APW | bottom | 0.000000 | 54.138 | -91.575 | 1 (~{INT}) | `/WAKE_INT_N` |
| `U3` | PCAL9535APW | bottom | 0.000000 | 54.138 | -81.575 | 1 (~{INT}) | `/WAKE_INT_N` |
| `U4` | BMI270 | bottom | -90.000000 | 56.750 | -68.838 | 1 (SDO) | `/05_I2C_DEVICES/BMI270_SDO_ADDR` |
| `U5` | MAX98357A | top | 0.000000 | 29.562 | -115.250 | 1 (DIN) | `/I2S_SPK_DOUT` |
| `U6` | TSOP38238 | top | 0.000000 | 64.210 | -4.600 | 1 (OUT) | `/IR_RX_GPIO44` |
| `U7` | E07-400M10S | bottom | 0.000000 | 34.000 | -127.000 | 1 (GND) | `GND` |
| `U8` | E22-900M22S | bottom | 0.000000 | 17.000 | -127.000 | 1 (GND) | `GND` |
| `U9` | ST25R3916-AQET | bottom | 0.000000 | 31.725 | -31.750 | 1 (VDD_IO) | `+3V3` |
| `U10` | USBLC6-2SC6 | top | 0.000000 | 50.263 | -141.750 | 1 (I/O1) | `/01_POWER_TREE/USB_D_CONN_N` |
| `U11` | BQ25185 | bottom | 0.000000 | 66.400 | -78.600 | 1 (SYS) | `/01_POWER_TREE/BQ25185_SYS` |
| `U12` | TPS63020 | bottom | 0.000000 | 68.100 | -96.200 | 1 (VINA) | `/01_POWER_TREE/BQ25185_SYS` |
| `U14` | MAX17048 | bottom | 0.000000 | 1.245 | -83.265 | 1 (CTG) | `GND` |
| `U16` | TCA4307DGKR | bottom | 0.000000 | 57.138 | -55.725 | 1 (EN) | `/ACC_PWR_EN` |
| `U17` | TPS61169DCKR | bottom | 0.000000 | 1.363 | -123.250 | 1 (SW) | `/03_SPI_A_DISPLAY_SD/BL_SW` |
| `U18` | LTC4368-1 | bottom | 180.000000 | 10.100 | -65.500 | 1 (VIN) | `/01_POWER_TREE/BAT_RAW` |
| `U19` | TLV7032 | bottom | 0.000000 | 1.558 | -29.230 | 1 (OUTA) | `/01_POWER_TREE/REC_POL_OK` |
| `U20` | TPS22950-Q1 | bottom | 180.000000 | 53.388 | -63.800 | 1 (ON) | `/ACC_3V3_EN` |
| `U21` | TPS61023 | bottom | 0.000000 | 57.087 | -40.400 | 1 (FB) | `/01_POWER_TREE/ACC_5V_FB` |
| `U22` | TPS22950-Q1 | bottom | 0.000000 | 53.862 | -43.950 | 1 (ON) | `/ACC_5V_SW_EN` |
| `Y1` | 27.12MHz 10pF 3225-4P | bottom | 180.000000 | 29.400 | -30.850 | 1 (1) | `/04_SPI_B_RADIOS_NFC/NFC_XOUT` |

## Manufacturer / CAM written acceptance -- B01-B14

Every item below is **PENDING** and needs the manufacturer's WRITTEN acceptance before an order is placed.  The register is `docs/full-beta-v2/assembly/RELEASE_ACCEPTANCE_REGISTER.json`.

| id | item | status |
|---|---|---|
| **B01** | exact 6-layer stack (JLC06161H-7628), copper weights, finished thickness 1.5744 +/- 0.10 mm and ENIG, with no house-default substitution | PENDING |
| **B02** | every land-intersecting via resin-filled, planarised and copper-capped (POFV) as listed in the fab notes | PENDING |
| **B03** | the 38 sub-floor vias the fab notes list under 'SUB-FLOOR VIAS', at the stated finished sizes | PENDING |
| **B04** | mask and stencil apertures, including the U9/U12 pads and the NFC tuning terminals | PENDING |
| **B05** | the J3 NPTH concession | PENDING |
| **B06** | MK1's acoustic port: unplated and unfilled | PENDING |
| **B07** | exact BOM, consignment, rotation and pin-1 per the CPL, the manual travelers, and 100 % electrical test | PENDING |
| **B08** | J4 finished barrels >= 0.70 mm and the exact tip/crimp/strain-relief process | PENDING |
| **B09** | the FOUR PLATED ROUTED SLOTS (Excellon G85) in the PTH drill file at J3's shield tabs, accepted as plated slots and not re-interpreted as round holes | PENDING |
| **B10** | the declared stackup used without substitution for the RF feeds and the USB pair drawn on it | PENDING |
| **B11** | the named soldermask-bridge / mask-dam exceptions | PENDING |
| **B12** | Tg >= 150 C FR4 laminate, certified | PENDING |
| **B13** | genuine-source allocation for the AOS AO4800 pass pair and the nine constrained fitted sourcing groups (consignment or authorised stock) | PENDING |
| **B14** | first-article inspection report for the bottom-terminated packages (X-ray of U11 DLH0010A, U9, U12 and the ESP32 module ground pad) before the remaining units are released | PENDING |
