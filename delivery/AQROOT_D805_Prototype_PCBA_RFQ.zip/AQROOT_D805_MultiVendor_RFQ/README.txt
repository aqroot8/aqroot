AQROOT D-805 — PROTOTYPE PCB / PCBA QUOTATION PACKAGE

Revision: D-805
Purpose: engineering quotation and DFM/DFA review for a low-volume prototype build.
Target assembly quantity: 2 fully assembled PCBAs.
If bare-PCB fabrication requires a higher minimum quantity, quote the minimum bare-board quantity and assemble 2 units.

This package is not a fabrication authorization.

D-805 manufacturing identity
- Board overall maximum extents: 77.000 x 151.000 mm
- Main body bottom edge: Y = 148.000 mm
- Two local bottom tabs extend to Y = 151.000 mm:
  - J2 microSD tab: X = 6.0..24.0 mm
  - J3 USB-C tab: X = 36.5..49.5 mm
- 6 copper layers
- Nominal finished thickness: 1.6 mm
- Target calculated stack: 1.5744 mm
- Surface finish: ENIG
- FR-4, Tg >= 150 C
- J5 Community Port: exact Samtec SSQ-124-02-G-S-RA; tail row fixed at X=65.900 mm; manufacturer mating face approximately X=75.910 mm. The connector intentionally overhangs the PCB edge.

Package contents
- Gerbers/: complete Gerber X2 / Excellon fabrication data
- Assembly/: assembly BOM, full BOM, DNP list, fitted/all position files, top/bottom assembly drawings
- AQROOT_D805_Fabrication_Notes.md
- AQROOT_D805_Stackup_Specification.txt
- RFQ_REQUIREMENTS.txt
- SHA256SUMS.txt

Important
Quote from the supplied files. Do not alter copper, solder mask, paste, drill, plated-slot, footprint, or board-outline geometry without written approval.
