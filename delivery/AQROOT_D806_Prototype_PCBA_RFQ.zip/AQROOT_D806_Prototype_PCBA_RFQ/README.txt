AQROOT D-806 -- PROTOTYPE (VENDOR-NEUTRAL, e.g. PCBWay) PCB/PCBA RFQ PACKAGE

Board sha256 0e59fb64fe72b0a54b9feea96c19bcaec2db52a82a871bcec270e064d7fda547
Fab MANIFEST sha256 651ceb4851e1097b87eb47ebfec1257a8752ae6a782f97ede4aa62790c19db4f

Quantity: 2 assembled PCBAs (bare-board MOQ may be higher).

Read RFQ_REQUIREMENTS.txt first.  Files:
- AQROOT_D806_Assembly_Bottom.pdf
- AQROOT_D806_Assembly_Top.pdf
- AQROOT_D806_BOM_assembly.csv
- AQROOT_D806_BOM_full.csv
- AQROOT_D806_Board_Profile.json
- AQROOT_D806_Board_Profile.pdf
- AQROOT_D806_Board_Thickness_Position.md
- AQROOT_D806_CPL.csv
- AQROOT_D806_CPL_all_incl_DNP.csv
- AQROOT_D806_DNP.csv
- AQROOT_D806_Fabrication_Notes.md
- AQROOT_D806_Gerbers.zip
- AQROOT_D806_Panel_Edge_Rail_Strategy.md
- AQROOT_D806_Reference_Index.csv
- AQROOT_D806_Reference_Locator_Bottom.pdf
- AQROOT_D806_Reference_Locator_Top.pdf
- AQROOT_D806_Sourcing_Decision_Record.md
- AQROOT_D806_Stackup_Specification.txt
- RFQ_REQUIREMENTS.txt

This package is for quotation and DFM/DFA review only.  It does NOT authorize
fabrication, assembly, payment or any non-cancellable procurement.
